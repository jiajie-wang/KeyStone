<template>
  <div class="container">

    <div class="D">
      <ul class=daohang>
        <div class="home">
          <svg t="1648193093016" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8080" width="30" height="30"><path d="M937.067069 482.335377 556.719504 106.839307c-1.89107-2.251274-6.123464-6.173606-11.997242-10.048867-9.889231-6.522554-21.093411-10.486842-33.388435-10.486842-13.137205 0-24.610514 3.984754-34.245965 10.590196-5.826705 3.997034-9.844206 8.076956-12.117992 11.117199L85.643566 482.381425c-14.653745 14.434757-14.653745 37.890982 0 52.358485 14.538111 14.380522 33.883715 8.316409 50.366108-7.919367L161.532977 501.587859l350.847693-339.869664 374.329501 368.073007c20.077268 13.223163 37.773302 17.377786 50.358945 4.946662C951.720813 520.273431 951.720813 496.801856 937.067069 482.335377z" p-id="8081" fill="#707070"></path><path d="M793.007045 462.046285c-17.391089 0-31.567973 13.938454-31.634488 31.236422l0 0.085958 0 0.089028 0 350.143659c0 17.416671-14.371312 31.602765-32.119535 31.602765l-84.129072 0 0-192.166671c0-49.818639-40.803311-90.111321-91.14486-90.111321l-85.268012 0c-50.326199 0-91.143836 40.300868-91.143836 90.111321l0 192.166671L293.437146 875.204116c-17.750269 0-32.119535-14.186094-32.119535-31.602765L261.317611 493.391177c-0.033769-17.355273-14.21884-31.343869-31.611975-31.343869-17.418718 0-31.589462 13.96506-31.658024 31.302937l0 354.429265c0 49.844222 40.808428 90.133833 91.14486 90.133833l141.253094 0 10.389628 0 0-10.391674 0-240.262062c0-17.410532 14.365172-31.580253 32.119535-31.580253l76.801177 0c17.756409 0 32.119535 14.169721 32.119535 31.580253l0 240.262062 0 10.391674 10.391674 0 141.253094 0c50.321082 0 91.14486-40.297798 91.14486-90.133833L824.665069 493.322615C824.527946 475.958132 810.380738 462.046285 793.007045 462.046285z" p-id="8082" fill="#707070"></path></svg></div>
        <li><router-link class="message-link" to="/">Home</router-link></li>

        <div class="social">
          <svg t="1648192706847" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5336" width="30" height="30"><path d="M661.99323 710.92L555.60323 604.53c-13.78-14.51-13.49-37.35 0.66-51.5 14.15-14.15 36.99-14.44 51.5-0.66L714.14323 658.76l57.04-57.04-379.1-379.11c-72.48-70.3-187.96-69.42-259.37 1.97-71.4 71.39-72.3 186.87-2.01 259.36L509.81323 863.1l59.95-59.95-106.39-106.38c-13.78-14.51-13.49-37.36 0.66-51.5 14.15-14.15 36.99-14.44 51.5-0.66L621.91323 751l40.08-40.08z m-128.3 231.03c-14.59 13.09-36.87 12.48-50.72-1.38L78.54323 536.15C11.56323 471.16-15.21677 375.12 8.48323 284.86c23.7-90.26 94.2-160.76 184.46-184.46 90.26-23.7 186.3 3.08 251.28 70.06l65.58 65.53 70.05-70C644.84323 99 740.87323 72.22 831.14323 95.92c90.26 23.7 160.76 94.19 184.46 184.46 23.7 90.26-3.07 186.3-70.06 251.28L541.21323 936.01c-2.27 2.28-4.79 4.3-7.52 5.99v-0.05z m28.32-653.76L823.34323 549.52l70.09-70c72.18-72.19 72.17-189.22-0.02-261.4-72.19-72.18-189.22-72.17-261.4 0.02l-69.96 70-0.04 0.05z m0 0" p-id="5337" fill="#707070"></path></svg></div>
        <li><router-link class="message-link" to="/">Social</router-link></li>

        <div class="message">
          <svg t="1648192823152" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6273" width="30" height="30"><path d="M721.338182 350.859636a64.512 64.512 0 0 1 64.512 64.488728 64.512 64.512 0 0 1-129.000727 0 64.488727 64.488727 0 0 1 64.488727-64.488728zM495.592727 350.859636a64.465455 64.465455 0 1 1 0 128.977455 64.465455 64.465455 0 0 1 0-128.977455zM269.847273 350.859636a64.512 64.512 0 1 1 0 129.000728 64.512 64.512 0 0 1 0-129.000728z" fill="#707070" p-id="6274"></path><path d="M427.264 930.769455a32.116364 32.116364 0 0 1-28.299636-16.756364l-109.544728-192.069818a32.186182 32.186182 0 0 1 12.032-43.962182 32.116364 32.116364 0 0 1 43.962182 12.032l81.850182 143.429818 81.850182-143.429818c8.843636-15.499636 28.509091-20.945455 43.985454-12.032 15.476364 8.797091 20.852364 28.485818 12.032 43.962182l-109.568 192.069818a32.302545 32.302545 0 0 1-28.229818 16.756364h-0.069818z" fill="#707070" p-id="6275"></path><path d="M837.934545 737.024H540.439273c-17.826909 0-32.256-14.405818-32.256-32.256s14.429091-32.256 32.256-32.256h297.495272c42.146909 0 76.404364-32.814545 76.404364-73.146182V230.795636c0-40.308364-34.280727-73.076364-76.404364-73.076363H186.042182c-42.123636 0-76.381091 32.768-76.381091 73.076363v368.570182c0 40.308364 34.257455 73.146182 76.381091 73.146182h129.419636c17.826909 0 32.256 14.405818 32.256 32.256s-14.429091 32.256-32.256 32.256H186.042182c-77.684364 0-140.893091-61.719273-140.893091-137.634909V230.795636c0-75.869091 63.208727-137.588364 140.893091-137.588363h651.892363c77.684364 0 140.916364 61.719273 140.916364 137.588363v368.570182c0 75.938909-63.232 137.658182-140.916364 137.658182z" fill="#707070" p-id="6276"></path></svg></div>
        <li><router-link class="message-link" to="/">Message</router-link></li>

        <div class="account">
          <svg t="1648192900920" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7159" width="30" height="30"><path d="M430.08 71.68c130.06848 0 235.52 105.45152 235.52 235.52 0 84.82816-44.8512 159.19104-112.14848 200.66304C679.40352 560.2304 768 684.48256 768 829.44v10.24a112.64 112.64 0 0 1-112.64 112.64H184.32A112.64 112.64 0 0 1 71.68 839.68v-10.24c0-149.79072 94.57664-277.46304 227.28704-326.59456A235.19232 235.19232 0 0 1 194.56 307.2C194.56 177.13152 300.01152 71.68 430.08 71.68z m-10.24 471.04c-158.35136 0-286.72 128.36864-286.72 286.72v10.24A51.2 51.2 0 0 0 184.32 890.88h471.04a51.2 51.2 0 0 0 51.2-51.2v-10.24c0-158.35136-128.36864-286.72-286.72-286.72zM731.136 156.22144c8.86784 3.8912 17.42848 8.3968 25.6 13.43488 57.5488 35.49184 93.184 95.68256 93.184 161.77152 0 60.14976-29.4912 114.688-76.63616 150.44608 106.86464 53.18656 179.03616 170.02496 179.03616 302.592a98.89792 98.89792 0 0 1-94.37184 98.87744l-4.4032 0.1024h-15.64672a30.72 30.72 0 0 1-2.9696-61.29664l2.9696-0.14336h15.64672c20.60288 0 37.33504-16.7936 37.33504-37.53984 0-131.72736-85.6064-243.24096-200.86784-266.9568a30.72 30.72 0 0 1-23.90016-36.27008l0.2048-1.00352a30.72 30.72 0 0 1 21.38112-22.97856c59.904-17.6128 100.78208-68.44416 100.78208-125.82912 0-44.15488-24.10496-84.86912-63.97952-109.4656a149.8112 149.8112 0 0 0-18.14528-9.54368 30.72 30.72 0 1 1 24.7808-56.19712zM430.08 133.12a174.08 174.08 0 1 0 0 348.16 174.08 174.08 0 0 0 0-348.16z" fill="#707070" p-id="7160"></path></svg></div>
        <li><router-link class="message-link" to="/">My account</router-link></li>
      </ul>
    </div>

    <div class="ding">
      <el-dropdown>
        <span class="el-dropdown-link">
          <svg t="1648971836670" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2459" width="30" height="30"><path d="M660.48 872.448q6.144 0-3.584 15.36t-29.696 33.792-47.104 33.792-57.856 15.36q-27.648 0-53.248-15.36t-45.056-33.792-29.696-33.792-6.144-15.36l272.384 0zM914.432 785.408q7.168 9.216 6.656 17.92t-4.608 14.848-10.24 9.728-12.288 3.584l-747.52 0q-14.336 0-20.992-11.776t4.608-29.184q17.408-30.72 40.96-68.608t44.544-81.408 36.352-92.16 15.36-101.888q0-51.2 14.336-92.16t37.376-71.68 53.248-52.224 62.976-32.768q-16.384-26.624-16.384-55.296 0-41.984 28.672-70.656t70.656-28.672 70.656 28.672 28.672 70.656q0 14.336-4.096 28.16t-11.264 25.088q34.816 11.264 66.048 32.768t54.272 53.248 36.864 72.704 13.824 91.136q0 51.2 15.36 100.864t36.864 94.208 45.568 81.408 43.52 63.488zM478.208 142.336q0 16.384 11.264 28.16t27.648 11.776l2.048 0q16.384-1.024 27.648-12.288t11.264-27.648q0-17.408-11.264-28.672t-28.672-11.264-28.672 11.264-11.264 28.672z" p-id="2460" fill="#707070"></path></svg>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item><router-link to="/friend"><div class="ding-nothing">new message from FRIEND</div></router-link></el-dropdown-item>
          <el-dropdown-item><router-link to="/group"><div class="ding-nothing">new message from GROUP</div></router-link></el-dropdown-item>
          <el-dropdown-item><div class="ding-nothing">contact has been added successfully</div></el-dropdown-item>
          <el-dropdown-item><div class="ding-nothing">contact has been turned down</div></el-dropdown-item>
          <el-dropdown-item><el-button type="text" @click="open"><div class="ding-nothing">receive a contact request</div></el-button></el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>

    <div class="content">
      <div class="subnevi">
        <div class="sub-in">
          <div class="section">
            <i class="fa fa-4x fa-user-o"></i>
            <div class="btn">
              <div class="avatar"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2Fe8094109bc36663bf322f9eb929f5cdd1e494a331059d-ynwzmA_fw658&refer=http%3A%2F%2Fhbimg.b0.upaiyun.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650815282&t=cabd766eb68be8ae30744640986191b1" /></div>
              <router-link class="link" to="/friend">friend</router-link>
            </div>
          </div>
        </div>
      </div>

      <div class="subnevi">
        <div class="sub-in">
          <div class="section">
            <i class="fa fa-4x fa-user-o"></i>
            <div class="btn">
              <div class="avatar"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fku.90sjimg.com%2Felement_origin_min_pic%2F16%2F11%2F24%2Ff2e86c6532186daa66fc510fcdb46f59.jpg&refer=http%3A%2F%2Fku.90sjimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650815560&t=d882913e8561af403841839670e43782" /></div>
              <router-link class="link" to="/group">group</router-link>
            </div>
          </div>
        </div>
      </div>

      <div class="fri-container">
          <div class="title"><em>My Friends</em></div>
        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>1</b></div>
        </div>
        </div>

        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>2</b></div>
        </div>
        </div>

        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>3</b></div>
        </div>
        </div>

        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>4</b></div>
        </div>
        </div>

        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>5</b></div>
        </div>
        </div>

        <div class="person-container">
        <div class="person">
          <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
          <div class="name"><b>6</b></div>
        </div>
        </div>

      <div class="hide">
        <el-collapse v-model="activeNames" @change="handleChange">
          <el-collapse-item name="1">

            <div class="person-con">
            <div class="person">
              <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
              <div class="name"><b>7</b></div>
            </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>8</b></div>
              </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>9</b></div>
              </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>10</b></div>
              </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>11</b></div>
              </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>12</b></div>
              </div>
            </div>

            <div class="person-con">
              <div class="person">
                <div class="ava"><img src="https://img0.baidu.com/it/u=3380931527,2824189433&fm=253&fmt=auto&app=138&f=JPEG?w=400&h=400" /></div>
                <div class="name"><b>13</b></div>
              </div>
            </div>

          </el-collapse-item>
        </el-collapse>
      </div>
      </div>

      <div class="gro-container">
        <div class="title"><em>My groups</em></div>

        <div class="group-container">
        <div class="group">
          <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
          <div class="gro-chat">Good good study</div>
        </div>
        </div>

        <div class="group-container">
        <div class="group">
          <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
          <div class="gro-chat">Good good study</div>
        </div>
        </div>

          <div class="group-container">
        <div class="group">
          <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
          <div class="gro-chat">Good good study</div>
        </div>
      </div>

        <div class="hide">
          <el-collapse v-model="activeNames" @change="handleChange">
            <el-collapse-item name="2">

              <div class="group-con">
                <div class="group">
                  <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
                  <div class="gro-chat">Good good study</div>
                </div>
              </div>

              <div class="group-con">
                <div class="group">
                  <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
                  <div class="gro-chat">Good good study</div>
                </div>
              </div>

              <div class="group-con">
                <div class="group">
                  <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
                  <div class="gro-chat">Good good study</div>
                </div>
              </div>

              <div class="group-con">
                <div class="group">
                  <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
                  <div class="gro-chat">Good good study</div>
                </div>
              </div>
              <div class="group-con">
                <div class="group">
                  <div class="gro-ava"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp6.itc.cn%2Fimages01%2F20210906%2F81a52f9026b24916af886aa4e59c755f.jpeg&refer=http%3A%2F%2Fp6.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650867106&t=c26523a3c990d405c54374b586f1585c" /></div>
                  <div class="gro-chat">Good good study</div>
                </div>
              </div>

            </el-collapse-item>
          </el-collapse>
        </div>
      </div>

      <div class="blank"></div>

    </div>
  </div>

</template>

<script>
  export default {
    data() {
      return {
        activeNames: ['1','2'],
      }
    },
    methods: {
      handleChange(val) {
        console.log(val);
      },

      open() {
        this.$confirm('Do you want to accept the request?', 'contact request', {
          confirmButtonText: 'Yes',
          cancelButtonText: 'No',
          type: 'warning'
        }).then(() => {
          this.$message({
            type: 'success',
            message: 'You have added the contact successfully!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: 'You have turned down the contact'
          });
        });
      }
    }
  }

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

  /* 框架 */
  .container {
    background-image: url("https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg-blog.csdnimg.cn%2Fimg_convert%2F1d9db770dee9b4f1995222d7c8e32726.png&refer=http%3A%2F%2Fimg-blog.csdnimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650869018&t=7dc1b0b7e70398cffae9dceec9b953ed");
    margin-top: -60px;
    position: absolute;
    width: 1250px;
  }
  .content{
    position: relative;
    margin-top: 60px;
    margin-left: 125px;
    width: 1000px;
    background-color:rgba(255,255,255,0.5);
    margin-bottom: 50px;
  }
  .fri-container{
    margin-left: 100px;
    width: 800px;
    background-color: rgba(255, 255, 255, 0.5);
    margin-top: 20px;
    position: relative;
  }
  .gro-container{
    margin-left: 100px;
    width: 800px;
    background-color: rgba(255, 255, 255, 0.5);
    margin-top: 20px;
    position: relative;
  }
  .title{
    position: relative;
    top: 10px;
    height: 40px;
    width:200px;
    font-size: 20px;
    text-decoration:none;
    color: #090909;
  }
  .blank{
    height: 40px;
    width: 800px;
  }

  /* 导航 */
  .daohang{
    position: absolute;
    left: 500px;
    top: -10px;
  }
  .D ul{
    margin: 25px auto;
    width: 700px;
  }
  .D li{
    list-style-type: none;
    float: left;
  }
  a{
    display: block;
    width: 150px;
    height: 40px;
    font-family: Microsoft Yahei;
    line-height: 40px;
    color: #fff;
    text-align: center;
    text-decoration: none;
    font-size: 18px;
  }
  a:hover{
    color: #718ba9;
  }
  .home svg{
    position: absolute;
    left: 55px;
    top: 5px;
  }
  .social svg{
    position: absolute;
    left: 195px;
    top: 5px;
  }
  .message svg{
    position: absolute;
    left: 335px;
    top: 5px;
  }
  .account svg{
    position: absolute;
    left: 475px;
    top: 5px;
  }



  .el-dropdown-link {
    cursor: pointer;
  }
  .ding-link{
    display: inline-block;
    position: relative;
    color: #606266;
    font-size: 14px;
  }
  .ding-nothing{
    display: inline-block;
    position: relative;
    color: #606266;
    font-size: 14px;
    width: 270px;
    text-align: center;
  }
  .ding{
    position: relative;
    margin-left: 1080px;
    margin-top: 20px;
    height: 0px;
  }

  /* 跳转聊天界面 */
  .subnevi{
    display: inline-block;
    width: 300px;
    margin-left: 50px;
    margin-top: 20px;
  }
  .sub-in{
    position: relative;
    width: 280px;
    height: 100px;
    opacity: 0.9;
    transform: scale(1);
    transition: .33s ease-in-out;
  }
  .section{
    flex:  0 0 20%;
    height: 80px;
    border: 1px solid #1a1818;
    padding: 10px;
    box-shadow: 0 5px 5px 2px #d57070;
  }
  .btn{
    background-color: rgb(248, 249, 250);
    box-sizing: border-box;
    width: 300px;
    color: #4876af;
    line-height: 60px;
    font-weight: 900;
  }
  .sub-in:hover{
    transform: none;
    opacity: 0.5;
  }

  .avatar img{
    display: inline;
    position: absolute;
    left:1.5rem;
    width: 100px;
    height: 80px;
  }
  .link{
    position: absolute;
    left: 160px;
    width:20px;
    font-size: 30px;
    text-decoration:none;
    color: #d57070;
  }

  /* 朋友list */
  .person-container{
    margin-left: 10px;
    width: 110px;
    height: 120px;
    display: inline-block;
    position: relative;
  }
  .person-con{
    margin-left: 40px;
    width: 84px;
    height: 120px;
    display: inline-block;
    position: relative;
    float: left;
  }
  .person-con .name{
    position: center;
    margin-top: -7px;
  }
  .person{
    background-image: linear-gradient(to top, white, #d5d5d5);
    flex: 0 0 20%;
    height: 80px;
    width: 80px;
    border: 2px solid #b4adad;
    padding: 10px;
    border-bottom-left-radius: 20px;
    border-bottom-right-radius: 20px;
    border-top-left-radius: 20px;
    border-top-right-radius: 20px;
  }
  .ava img{
    display: inline-block;
    width: 60px;
    height: 60px;
    border-radius: 50%;
  }
  .name{
    display: inline-block;
    font-family: "Times New Roman";
    color: #807e7e;
    font-size: 20px;
  }

  /* 群聊list */
  .group-container{
    margin-left: 10px;
    width: 250px;
    height: 130px;
    display: inline-block;
    position: relative;

  }
  .group-con{
    margin-left: 15px;
    width: 250px;
    height: 130px;
    display: inline-block;
    float: left;
    position: relative;
  }
  .group{
    background: linear-gradient(to right, #b0afaf 1px,transparent 1px),
    linear-gradient(to bottom,#b0afaf 1px,transparent 1px);
    /*background: radial-gradient(circle , #5a5a5a .5px, transparent .5px);   点点*/
    background-repeat: repeat;
    background-size: 9px 9px;
    flex: 0 0 20%;
    height: 100px;
    width: 220px;
    padding: 10px;
  }
  .gro-ava img{
    position: relative;
    margin-left: -60px;
    margin-top: 5px;
    width: 110px;
    height: 90px;
  }
  .gro-chat{
    position: absolute;
    left: 170px;
    top: 20px;
    width:10px;
    line-height: 25px;
    font-size: 16px;
    text-decoration:none;
    color: #090909;
  }

</style>
