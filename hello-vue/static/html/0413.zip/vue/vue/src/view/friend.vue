<template>
  <div class="container">

    <div>
      <ul class=daohang>
        <div class="home">
          <svg t="1648193093016" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8080" width="30" height="30"><path d="M937.067069 482.335377 556.719504 106.839307c-1.89107-2.251274-6.123464-6.173606-11.997242-10.048867-9.889231-6.522554-21.093411-10.486842-33.388435-10.486842-13.137205 0-24.610514 3.984754-34.245965 10.590196-5.826705 3.997034-9.844206 8.076956-12.117992 11.117199L85.643566 482.381425c-14.653745 14.434757-14.653745 37.890982 0 52.358485 14.538111 14.380522 33.883715 8.316409 50.366108-7.919367L161.532977 501.587859l350.847693-339.869664 374.329501 368.073007c20.077268 13.223163 37.773302 17.377786 50.358945 4.946662C951.720813 520.273431 951.720813 496.801856 937.067069 482.335377z" p-id="8081" fill="#707070"></path><path d="M793.007045 462.046285c-17.391089 0-31.567973 13.938454-31.634488 31.236422l0 0.085958 0 0.089028 0 350.143659c0 17.416671-14.371312 31.602765-32.119535 31.602765l-84.129072 0 0-192.166671c0-49.818639-40.803311-90.111321-91.14486-90.111321l-85.268012 0c-50.326199 0-91.143836 40.300868-91.143836 90.111321l0 192.166671L293.437146 875.204116c-17.750269 0-32.119535-14.186094-32.119535-31.602765L261.317611 493.391177c-0.033769-17.355273-14.21884-31.343869-31.611975-31.343869-17.418718 0-31.589462 13.96506-31.658024 31.302937l0 354.429265c0 49.844222 40.808428 90.133833 91.14486 90.133833l141.253094 0 10.389628 0 0-10.391674 0-240.262062c0-17.410532 14.365172-31.580253 32.119535-31.580253l76.801177 0c17.756409 0 32.119535 14.169721 32.119535 31.580253l0 240.262062 0 10.391674 10.391674 0 141.253094 0c50.321082 0 91.14486-40.297798 91.14486-90.133833L824.665069 493.322615C824.527946 475.958132 810.380738 462.046285 793.007045 462.046285z" p-id="8082" fill="#707070"></path></svg></div>
          <li><router-link class="message-link" to="/">Home</router-link></li>

        <div class="social">
          <svg t="1648192706847" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5336" width="30" height="30"><path d="M661.99323 710.92L555.60323 604.53c-13.78-14.51-13.49-37.35 0.66-51.5 14.15-14.15 36.99-14.44 51.5-0.66L714.14323 658.76l57.04-57.04-379.1-379.11c-72.48-70.3-187.96-69.42-259.37 1.97-71.4 71.39-72.3 186.87-2.01 259.36L509.81323 863.1l59.95-59.95-106.39-106.38c-13.78-14.51-13.49-37.36 0.66-51.5 14.15-14.15 36.99-14.44 51.5-0.66L621.91323 751l40.08-40.08z m-128.3 231.03c-14.59 13.09-36.87 12.48-50.72-1.38L78.54323 536.15C11.56323 471.16-15.21677 375.12 8.48323 284.86c23.7-90.26 94.2-160.76 184.46-184.46 90.26-23.7 186.3 3.08 251.28 70.06l65.58 65.53 70.05-70C644.84323 99 740.87323 72.22 831.14323 95.92c90.26 23.7 160.76 94.19 184.46 184.46 23.7 90.26-3.07 186.3-70.06 251.28L541.21323 936.01c-2.27 2.28-4.79 4.3-7.52 5.99v-0.05z m28.32-653.76L823.34323 549.52l70.09-70c72.18-72.19 72.17-189.22-0.02-261.4-72.19-72.18-189.22-72.17-261.4 0.02l-69.96 70-0.04 0.05z m0 0" p-id="5337" fill="#707070"></path></svg></div>
          <li><router-link class="message-link" to="/">Social</router-link></li>

        <div class="message">
          <svg t="1648192823152" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="6273" width="30" height="30"><path d="M721.338182 350.859636a64.512 64.512 0 0 1 64.512 64.488728 64.512 64.512 0 0 1-129.000727 0 64.488727 64.488727 0 0 1 64.488727-64.488728zM495.592727 350.859636a64.465455 64.465455 0 1 1 0 128.977455 64.465455 64.465455 0 0 1 0-128.977455zM269.847273 350.859636a64.512 64.512 0 1 1 0 129.000728 64.512 64.512 0 0 1 0-129.000728z" fill="#707070" p-id="6274"></path><path d="M427.264 930.769455a32.116364 32.116364 0 0 1-28.299636-16.756364l-109.544728-192.069818a32.186182 32.186182 0 0 1 12.032-43.962182 32.116364 32.116364 0 0 1 43.962182 12.032l81.850182 143.429818 81.850182-143.429818c8.843636-15.499636 28.509091-20.945455 43.985454-12.032 15.476364 8.797091 20.852364 28.485818 12.032 43.962182l-109.568 192.069818a32.302545 32.302545 0 0 1-28.229818 16.756364h-0.069818z" fill="#707070" p-id="6275"></path><path d="M837.934545 737.024H540.439273c-17.826909 0-32.256-14.405818-32.256-32.256s14.429091-32.256 32.256-32.256h297.495272c42.146909 0 76.404364-32.814545 76.404364-73.146182V230.795636c0-40.308364-34.280727-73.076364-76.404364-73.076363H186.042182c-42.123636 0-76.381091 32.768-76.381091 73.076363v368.570182c0 40.308364 34.257455 73.146182 76.381091 73.146182h129.419636c17.826909 0 32.256 14.405818 32.256 32.256s-14.429091 32.256-32.256 32.256H186.042182c-77.684364 0-140.893091-61.719273-140.893091-137.634909V230.795636c0-75.869091 63.208727-137.588364 140.893091-137.588363h651.892363c77.684364 0 140.916364 61.719273 140.916364 137.588363v368.570182c0 75.938909-63.232 137.658182-140.916364 137.658182z" fill="#707070" p-id="6276"></path></svg></div>
          <li><router-link class="message-link" to="/">Message</router-link></li>

        <div class="account">
          <svg t="1648192900920" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="7159" width="30" height="30"><path d="M430.08 71.68c130.06848 0 235.52 105.45152 235.52 235.52 0 84.82816-44.8512 159.19104-112.14848 200.66304C679.40352 560.2304 768 684.48256 768 829.44v10.24a112.64 112.64 0 0 1-112.64 112.64H184.32A112.64 112.64 0 0 1 71.68 839.68v-10.24c0-149.79072 94.57664-277.46304 227.28704-326.59456A235.19232 235.19232 0 0 1 194.56 307.2C194.56 177.13152 300.01152 71.68 430.08 71.68z m-10.24 471.04c-158.35136 0-286.72 128.36864-286.72 286.72v10.24A51.2 51.2 0 0 0 184.32 890.88h471.04a51.2 51.2 0 0 0 51.2-51.2v-10.24c0-158.35136-128.36864-286.72-286.72-286.72zM731.136 156.22144c8.86784 3.8912 17.42848 8.3968 25.6 13.43488 57.5488 35.49184 93.184 95.68256 93.184 161.77152 0 60.14976-29.4912 114.688-76.63616 150.44608 106.86464 53.18656 179.03616 170.02496 179.03616 302.592a98.89792 98.89792 0 0 1-94.37184 98.87744l-4.4032 0.1024h-15.64672a30.72 30.72 0 0 1-2.9696-61.29664l2.9696-0.14336h15.64672c20.60288 0 37.33504-16.7936 37.33504-37.53984 0-131.72736-85.6064-243.24096-200.86784-266.9568a30.72 30.72 0 0 1-23.90016-36.27008l0.2048-1.00352a30.72 30.72 0 0 1 21.38112-22.97856c59.904-17.6128 100.78208-68.44416 100.78208-125.82912 0-44.15488-24.10496-84.86912-63.97952-109.4656a149.8112 149.8112 0 0 0-18.14528-9.54368 30.72 30.72 0 1 1 24.7808-56.19712zM430.08 133.12a174.08 174.08 0 1 0 0 348.16 174.08 174.08 0 0 0 0-348.16z" fill="#707070" p-id="7160"></path></svg></div>
          <li><router-link class="message-link" to="/">My account</router-link></li>
      </ul>
    </div>

    <div class="left">
      <!-- 通讯录 -->
      <div class="left-title">
        <div class="title-image"><img src="https://img2.baidu.com/it/u=343850545,2320437498&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
        <router-link class="gro-link" to="/group"><b>Group&nbsp</b><svg t="1648314160931" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5621" width="20" height="20"><path d="M47.104 453.632q0-43.008 20.992-57.856t66.048-14.848q20.48 0 64.512 0.512t93.696 0.512 96.768 0.512 74.752 0.512q38.912 1.024 61.44-6.656t22.528-35.328q0-20.48 1.536-48.64t1.536-48.64q1.024-35.84 20.48-45.568t49.152 14.848q30.72 24.576 71.68 58.368t84.992 69.12 86.016 69.632 74.752 59.904q29.696 24.576 30.208 46.592t-28.16 45.568q-29.696 24.576-70.144 56.32t-83.968 65.536-85.504 67.072-74.752 58.88q-35.84 28.672-58.88 21.504t-22.016-44.032l0-24.576 0-29.696q0-15.36-0.512-30.208t-0.512-27.136q0-25.6-15.36-32.256t-41.984-6.656q-29.696 0-77.824-0.512t-100.352-0.512-101.376-0.512-79.872-0.512q-13.312 0-27.648-2.56t-26.112-9.728-18.944-20.992-7.168-37.376q0-27.648-0.512-53.248t0.512-57.344z" p-id="5622" fill="#ffffff"></path></svg></router-link>
      </div>

      <div class="fri-search">
        <div class="my-friends"><b>My friends</b></div>
        <div class="search">
          <el-input v-model="input" placeholder="search for friend"></el-input>
        </div>
      </div>

      <div class="namelist-container">
        <dl id="namesList">
          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Caroline</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Lexi</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Jenna</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Valerie</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Rebecca</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Klaus</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Jeremy</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Elijah</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Damon</dd>
          </div>

          <div class="singlenamelist">
            <div class="ava"><img src="https://img0.baidu.com/it/u=1059178276,949063718&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div>
            <dd>Tyler</dd>
          </div>
        </dl>
      </div>
    </div>

    <div class="right">
      <!-- 对话界面 -->
      <div class="right-title">Caroline</div>
      <div class="content">
        <div class="item item-center"><span>昨天 12:35</span></div>
        <div class="item item-center"><span>你已添加了xx，现在可以开始聊天了。</span></div>
        <div class="item item-left"><div class="avatar"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fnimg.ws.126.net%2F%3Furl%3Dhttp%253A%252F%252Fdingyue.ws.126.net%252F2021%252F0719%252Fb0da86c5j00qwhtvj001ec000io00ioc.jpg%26thumbnail%3D650x2147483647%26quality%3D80%26type%3Djpg&refer=http%3A%2F%2Fnimg.ws.126.net&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650552239&t=f3a6b1831a8db3d2b7107711d2dff1fc" /></div><div class="bubble bubble-left">您好,我在武汉，你可以直接送过来吗，我有时间的话，可以自己过去拿<br/>可以吗</div></div>
        <div class="item item-right"><div class="bubble bubble-right">hello<br/>你好呀</div><div class="avatar"><img src="https://img2.baidu.com/it/u=343850545,2320437498&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div></div>
        <div class="item item-center"><span>昨天 13:15</span></div>
        <div class="item item-right"><div class="bubble bubble-right">刚刚不在，不好意思</div><div class="avatar"><img src="https://img2.baidu.com/it/u=343850545,2320437498&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div></div>
        <div class="item item-left"><div class="avatar"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fnimg.ws.126.net%2F%3Furl%3Dhttp%253A%252F%252Fdingyue.ws.126.net%252F2021%252F0719%252Fb0da86c5j00qwhtvj001ec000io00ioc.jpg%26thumbnail%3D650x2147483647%26quality%3D80%26type%3Djpg&refer=http%3A%2F%2Fnimg.ws.126.net&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650552239&t=f3a6b1831a8db3d2b7107711d2dff1fc" /></div><div class="bubble bubble-left">没事<br/>你继续！</div></div>
        <div class="item item-left"><div class="avatar"><img src="https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fnimg.ws.126.net%2F%3Furl%3Dhttp%253A%252F%252Fdingyue.ws.126.net%252F2021%252F0719%252Fb0da86c5j00qwhtvj001ec000io00ioc.jpg%26thumbnail%3D650x2147483647%26quality%3D80%26type%3Djpg&refer=http%3A%2F%2Fnimg.ws.126.net&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650552239&t=f3a6b1831a8db3d2b7107711d2dff1fc" /></div><div class="bubble bubble-left">你发一个<br/>刚刚网卡了</div></div>
        <div class="item item-right"><div class="bubble bubble-right">可以<br/>一会儿再发给你</div><div class="avatar"><img src="https://img2.baidu.com/it/u=343850545,2320437498&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=500" /></div></div>
      </div>
      <div class="input-area">
        <textarea name="text" id="textarea"></textarea>
        <div class="button-area">
          <button id="send-btn" onclick="send()">发 送</button>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  export default {
    name: 'HelloWorld',
    data() {
      return {
        input: ''
      }
    }
  }
</script>


<style scoped>

  /* 框架 */
  .container{
    background-image: url("https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fimg-blog.csdnimg.cn%2Fimg_convert%2F1d9db770dee9b4f1995222d7c8e32726.png&refer=http%3A%2F%2Fimg-blog.csdnimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1650869018&t=7dc1b0b7e70398cffae9dceec9b953ed");
    background-size: cover;
    height: 606px;
    width: 1265px;
    position: absolute;
    top: 0px;
  }
  .left{
    position: absolute;
    left: 137px;
    top: 60px;
    border: 0.5px solid #e0e0e0;
    background-color: #3d3a3a;
    border-radius: 4px;
  }
  .right{
    height: 510px;
    width: 700px;
    border-radius: 4px;
    border: 0.5px solid #e0e0e0;
    display: flex;
    flex-flow: column;
    overflow: hidden;
    position: absolute;
    left: 436px;
    top: 60px;
  }

  /* 导航 */
  .daohang{
    position: absolute;
    left: 500px;
    top: -15px;
    width: 600px;
  }
  ul{
    margin: 25px auto;
    width: 1000px;
  }
  li{
    list-style-type: none;
    float: left;
  }
  .message-link{
    display: block;
    width: 150px;
    height: 40px;
    font-family: Microsoft Yahei;
    line-height: 40px;
    color: #fff;
    text-align: center;
    text-decoration: none;
    font-size: 15px;
  }
  a:hover{
    color: #718ba9;
  }
  .home svg{
    position: absolute;
    left: 20px;
  }
  .social svg{
    position: absolute;
    left: 160px;
  }
  .message svg{
    position: absolute;
    left: 300px;
  }
  .account svg{
    position: absolute;
    left: 440px;
  }

  /* 通讯录 */
  .left-title{
    height: 60px;
    width: 300px;
    background-color: #2d2a2a;
  }
  .title-image img{
    position: absolute;
    left: 20px;
    top: 2px;
    width: 55px;
    height: 55px;
    border-radius: 50%;
  }
  .gro-link{
    text-decoration: none;
    display: inline;
    position: absolute;
    top: 14px;
    right: -5px;
    height: 40px;
    width: 120px;
    font-size: 12px;
    color: #fdfcfc;
  }
  .left-title svg{
    position: absolute;
    top: -2px;
    width: 20px;
  }
  .fri-search{
    height: 60px;
  }
  .my-friends{
    display: inline;
    width: 100px;
    position: absolute;
    top: 80px;
    left:20px;
    color: white;
  }
  .search{
    width: 150px;
    height: 40px;
    position: absolute;
    top: 70px;
    left: 125px;
  }
  .namelist-container{
    height: 390px;
    width: 300px;
    display: flex;
    flex-flow: column;
    overflow: hidden;
    overflow-y: scroll;
  }
  .namelist-container:hover::-webkit-scrollbar-thumb{
    background:rgba(0,0,0,0.1);
  }
  .namelist-container #namesList dd {
    padding-left: 3rem;
    line-height: 4rem;
    font-size: 0.9rem;
    color: white;
  }
  .singlenamelist{
    position: relative;
    border: 0.5px solid #565555;
  }
  .singlenamelist .ava img{
    display:inline-block;
    position: absolute;
    left: 2rem;
    top: 0.4rem;
    width: 50px;
    height: 50px;
    border-radius: 50%;
  }

  /* 聊天界面 */
  *{
    padding: 0;
    margin: 0;
  }
  body{
    height: 100vh;
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .right-title{
    height: 30px;
    width: 700px;
    background-color: #f3f2f2;
    padding-top: 0.8rem;
    border: 0.5px solid #a4a4a4;
  }

  .content{
    width: calc(100% - 40px);
    padding: 20px;
    overflow-y: scroll;
    flex: 1;
    background-color: #f3f2f2;
  }
  .content:hover::-webkit-scrollbar-thumb{
    background:rgba(0,0,0,0.1);
  }
  .bubble{
    max-width: 400px;
    padding: 10px;
    border-radius: 5px;
    position: relative;
    color: #000;
    word-wrap:break-word;
    word-break:normal;
  }
  .item-left .bubble{
    margin-left: 15px;
    background-color: #fff;
  }
  .item-left .bubble:before{
    content: "";
    position: absolute;
    width: 0;
    height: 0;
    border-left: 10px solid transparent;
    border-top: 10px solid transparent;
    border-right: 10px solid #fff;
    border-bottom: 10px solid transparent;
    left: -20px;
  }
  .item-right .bubble{
    margin-right: 15px;
    background-color: #6396d2;
  }
  .item-right .bubble:before{
    content: "";
    position: absolute;
    width: 0;
    height: 0;
    border-left: 10px solid #6396d2;
    border-top: 10px solid transparent;
    border-right: 10px solid transparent;
    border-bottom: 10px solid transparent;
    right: -20px;
  }
  .item{
    margin-top: 15px;
    display: flex;
    width: 100%;
    font-size: 10px;
  }
  .item.item-right{
    justify-content: flex-end;
  }
  .item.item-center{
    justify-content: center;
  }
  .item.item-center span{
    font-size: 12px;
    padding: 2px 4px;
    color: #fff;
    background-color: #dadada;
    border-radius: 3px;
    -moz-user-select:none; /*火狐*/
    -webkit-user-select:none; /*webkit浏览器*/
    -ms-user-select:none; /*IE10*/
    -khtml-user-select:none; /*早期浏览器*/
    user-select:none;
  }
  .avatar img{
    width: 42px;
    height: 42px;
    border-radius: 50%;
  }
  .input-area{
    border-top:0.5px solid #e0e0e0;
    height: 150px;
    width: 700px;
    display: flex;
    flex-flow: column;
    background-color: #fff;
  }
  textarea{
    flex: 1;
    padding: 5px;
    font-size: 14px;
    border: none;
    cursor: pointer;
    overflow-y: auto;
    overflow-x: hidden;
    outline:none;
    resize:none;
  }
  .button-area{
    display: flex;
    height: 40px;
    margin-right: 10px;
    line-height: 40px;
    padding: 5px;
    justify-content: flex-end;
  }
  .button-area button{
    width: 80px;
    border: none;
    outline: none;
    border-radius: 4px;
    float: right;
    cursor: pointer;
  }

</style>
